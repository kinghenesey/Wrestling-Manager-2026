export function Divisions() { return (<div className="space-y-4"><h1 className="text-2xl font-bold text-zinc-100">Divisions</h1><p className="text-zinc-500">Coming soon.</p></div>) }
