export function Dashboard() { return (<div className="space-y-4"><h1 className="text-2xl font-bold text-zinc-100">Dashboard</h1><p className="text-zinc-500">Dashboard loading...</p></div>) }
