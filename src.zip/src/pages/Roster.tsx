export function Roster() { return (<div className="space-y-4"><h1 className="text-2xl font-bold text-zinc-100">Roster</h1><p className="text-zinc-500">Roster loading...</p></div>) }
