import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom"
import { AppLayout }   from "./components/layout/AppLayout"
import { Dashboard }   from "./pages/Dashboard"
import { Roster }      from "./pages/Roster"
import { Storylines }  from "./pages/Storylines"
import { ShowPlanner } from "./pages/ShowPlanner"
import { Academy }     from "./pages/Academy"
import { Finances }    from "./pages/Finances"
import { Agents }      from "./pages/Agents"
import { Divisions }   from "./pages/Divisions"
import { Underground } from "./pages/Underground"
import { Awards }      from "./pages/Awards"
import { Calendar }    from "./pages/Calendar"
import { Settings }    from "./pages/Settings"

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard"    element={<Dashboard />} />
          <Route path="roster"       element={<Roster />} />
          <Route path="storylines"   element={<Storylines />} />
          <Route path="show-planner" element={<ShowPlanner />} />
          <Route path="academy"      element={<Academy />} />
          <Route path="finances"     element={<Finances />} />
          <Route path="agents"       element={<Agents />} />
          <Route path="divisions"    element={<Divisions />} />
          <Route path="underground"  element={<Underground />} />
          <Route path="awards"       element={<Awards />} />
          <Route path="calendar"     element={<Calendar />} />
          <Route path="settings"     element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}